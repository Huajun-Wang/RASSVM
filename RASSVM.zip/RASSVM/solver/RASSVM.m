function  out= RASSVM(X,y,pars)
% Inputs:
%       X    -- the sample data, dimension, \in\R^{m-by-n}; (required)
%       y    -- the classes of the sample data, \in\R^m; (required)
%               y_i \in {+1,-1}, i=1,2,...,m
%       pars -- parameters (optional)
%
% pars:     Parameters are all OPTIONAL
%               pars.kappa   --  Starting point of kappa \in\R^m,  (default, zeros(m,1))
%               pars.nu  --  A positive scalar in (2^-4,2^-3,...,2^4).(default, 1)
%               pars.nu1  --  A positive scalar in (10^-4,2^-3,...,10^4).(default, 10^-4)
% %             pars.delta      --  A positive scalar in (2^-4,...,2^4).(default, 1)
%               pars.maxit   --  Maximum number of iterations, (default,1000)
%               pars.tol     --  Tolerance of the halting condition, (default,1e-3)
%
% Outputs:
%     Out.iter:          Number of iterations
%     Out.time:          CPU time
%     Out.bbeta0:        The solution of the primal problem, namely the classifier
%     Out.h:             The solution h
%     Out.kappa:         The solution kappa
%     Out.alpha:         The solution alpha
%     Out.nsv:           Number of support vectors
%     Out.acc:           Training classification accuracy
%     Out.error:         Classification error




if nargin<3;               pars  = [];                             end
if isfield(pars,'nu'); nu= pars.nu;else; nu     = 1;    end
if isfield(pars,'maxit');  maxit = pars.maxit; else; maxit = 1e3;  end
if isfield(pars,'delta');     delta = pars.delta; else; delta = 1;    end
if isfield(pars,'tol');    tol   = pars.tol;   else; tol   = 1e-3; end
if isfield(pars,'nv1'); nu1= pars.nu1;else; nu1     = 10^-4;    end
[m,n]  = size(X);
 beta=zeros(n,1);%beta  = ones(n,1)/100
kappa    = zeros(m,1);
kappadelta = kappa;
R      = GetR(y,m,n);%
H      = y.*X;
g      = 1-H*beta;
beta0      = 0;   %beta0= 1 or -1;
q      = g-beta0*y;
eps  = ones(1,4);
Fnorm  = @(var)norm(var)^2;
to     = tic;
flag   = 0;
for iter  = 1:1:maxit
    % update R -------------------------------------
    if nu/delta>=1/50
       con = sqrt(2*nu/delta);
       R   = find(q >0 & q <= con);
    else
       R1   = find(q>0 & q<10*nu/delta);
       R2   = find(q>=(10*nu/delta) & q<1/5);
       R    = union(R1,R2);
     end
    % update h -------------------------------------
    if nu/delta>=1/50
         h = Prox(q,nu,delta,R);
    else
         h = Prox1(q,nu,delta,R1,R2);
    end
    % update beta--------------------------------------
    tmp    = 1 - h - kappadelta; 
    v      = tmp - beta0*y;
    nR     = nnz(R);
    HR     = H(R,:);
    if min(n,nR)< 1e3
        HRt     = HR';
        if  n  <= nR
            HHR = HRt*HR;
            HHR(1:1+n:end) = HHR(1:1+n:end) + 1/delta;
            beta   = HHR\(HRt*v(R)-nu1*sign(beta));
        else
            if nR >0
                HHR=HHR; delta=delta;
                ATt=HRt;HR=HR;nT=nR;
 %               NNM(1:1+nM:end) = NNM(1:1+nM:end) + 1/delta;
%                beta  = NMt*(NNM\v(M));
               HHR = HR *HRt;               
                beta  = (eye(n)-delta*HRt*inv(eye(nT)+delta*HHR)*HR)*(delta*HRt*v(R)-nu1*sign(beta));    
                
            else
                beta  = -ones(n,1); R=1;
            end
        end
    else
        if  n  <= nR
            beta = my_cg(HR,delta,(v(R)'*HR)',n,1);
        else
            betaR = my_cg(HR,delta,v(R),nR,2);
            beta  = (betaR'*HR)';
        end
    end

    % update beta0-------------------------------------
    Hbeta     = H*beta;
    beta0      = mean((tmp(R)-Hbeta(R)).*y(R));


    % update kappa-------------------------------
    kappaR   = kappa(R);
    kappa    = zeros(m,1);
    omega  = Hbeta + h - 1 + beta0*y;
    kappaR   = kappaR + delta * omega(R);
    kappa(R) = kappaR;


     % stopping crterion --------------------------
    kappadelta = kappa/delta;
    rkappa   = h  - kappadelta;
    ind    = (rkappa<=0 | rkappa>sqrt(2*nu/delta));%eps

    eps(1) = Fnorm(beta'+ kappaR'*HR+nu1*sign(beta)')/(1+Fnorm(beta));
    eps(2) = abs(y(R)'*kappaR)/(1+nR);
    eps(3) = Fnorm(omega)/(m+Fnorm(Hbeta)); %
    if nu/delta>=1/50
    eps(4) = Fnorm(h-rkappa.*ind)/(1+Fnorm(h));
    else
    eps(4) = Fnorm(h - Prox1(q,nu,delta,R1,R2))/(1+Fnorm(h));
    end
    error    = max(eps);
     CPU     = toc(to);
    ACC      = 1-nnz(sign(y.*Hbeta+beta0)-y)/length(y);
   tACC(iter)= ACC;
    if error < tol && ACC>0.5; flag=2; break;  end

    q        = rkappa - omega;
    delta0     = min(q(q>0));
    if isempty(delta0); delta0 = 1e-8; end

    if mod(iter,10)==0
        if eps(3) > 1e-3
           delta = min(delta*2,10);
        elseif eps(1) > 1e-3
           delta = min(max(0.01,delta/1.25),5);
        end
    end
 if    m<n || m>10000
    if delta > 2*nu/delta0^2  % exclude zero solutions
       delta = 1.9*nu/delta0^2;
    end
 end

 if iter>5 && m>n && m<=10000

 if std(tACC(iter-3:iter))<=1e-3
  Cons = sqrt(2*nu/delta);  m0   = max(20,2*n);
  R0   = find(q >0 & q <= Cons);

 if nnz(R0)<5 || nnz(R0)>=m0
    flag=1;  q1 = q(find(q>0));
 if nnz(q1)>m0
    s  = mink(q1,m0);    delta = min(2*nu/s(m0)^2,10000);
 else
 [~,R] = mink(abs(q),m0); flag=0;
  end
  end
  end
  end
end
% fprintf('----------------------------------------------------\n');

out.iter = iter;
out.time = CPU;
out.bbeta0   = [beta;beta0];
out.h    = h;
out.kappa  = kappa;
out.nsv  = nR;
out.acc  = ACC;
out.error= error;
out.flag = flag;
end

% proxiaml-----------------------------------------------------------------
function h = Prox(q,nu,delta,R)
if isempty(R)
    tmp1 = sqrt(2*nu/delta);
    R    = find(q >0 & q <= tmp1);
    h    = q;
    h(R) = 0;
   else
    h    = q;
    h(R) = 0;
 end

end

function h = Prox1(q,nu,delta,R1,R2)
   R=union(R1, R2);
if isempty(R)
    tmp1 = sqrt(2*nu/delta);
    R    = find(q >0 & q <= tmp1);
    h    = q;
    h(R) = 0;
else
    h    = q;
    h(R1)= 0;
    h(R2)= (q(R2)-10*nu/delta)/(1-50*nu/delta);
 end

end

% %%% -----------------------------------------------------------------
function R = GetR(y,m,n)
if  m>n
s0      = ceil(n*(log(m/n))^2);
R1      = find(y==1);  nR1= nnz(R1);
R2      = find(y==-1); nR2= nnz(R2);
if  nR1 < s0
    R  = [R1; R2(1:(s0-nR1))];
elseif nR2 < s0
    R  = [R1(1:(s0-nR2)); R2];
else
    R  = [R1(1:ceil(s0/2)); R2(1:(s0-ceil(s0/2)))];
end
R      = sort(R(1:s0));
else
    R  = 1:length(y);
end
end

% Conjugate gradient method-------------------------------------------------
function x = my_cg(HR,delta,beta0,n,flag)
    x = zeros(n,1);
    h = beta0;
    e = sum(h.*h);
    t = e;
    for i = 1: 50
        if e < 1e-10*t; break; end
        if  i == 1
            p = h;
        else
            p = h + (e/e0)*p;
        end
        if  flag==1
            beta  = p/delta  + ((HR*p)'*HR)';
        else
            beta  = p/delta  + HR*(p'*HR)';
        end
        a  = e/sum(p.*beta);
        x  = x + a * p;
        h  = h - a * beta;
        e0 = e;
        e  = sum(h.*h);
    end

end