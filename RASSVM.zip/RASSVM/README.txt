This source code is programmed based on the algorithm described in:

Fast elastic net support vector machine with ramp squared loss for large-scale classification

Huajun Wang,  Wenqian Li, Yuanhai Shao

Please give credits to this paper if you use the code for your research.
